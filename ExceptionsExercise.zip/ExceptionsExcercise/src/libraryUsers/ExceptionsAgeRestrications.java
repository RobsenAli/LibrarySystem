package libraryUsers;

public class ExceptionsAgeRestrications extends Exception {

	public ExceptionsAgeRestrications(String message) {
		super(message);

	}
}
